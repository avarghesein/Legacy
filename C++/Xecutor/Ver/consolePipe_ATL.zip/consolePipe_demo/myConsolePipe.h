#include "resource.h"

#define UWM_PIPEBROKEN (WM_APP+1) /* this could have been registered */

//#include "consolePipe.h"
class CMyConsolePipe : public CConsolePipe
{
public:
	CMyConsolePipe(BOOL bWinNT, CEdit wOutput, DWORD flags) : 
		CConsolePipe(bWinNT, wOutput, flags)
	{
	}

	virtual void OnReceivedOutput(LPCTSTR pszText) 
	{
		if(!pszText) { // child has terminated
			CWindow dlg(m_wndOutput.GetParent());
			ATLASSERT(dlg.IsWindow());

			// notify the main dialog that the process has ended
			dlg.SendMessage(UWM_PIPEBROKEN, (WPARAM)this);
			// note that this is called from the background thread context

			// soon this class will self-destruct
		}

		CConsolePipe::OnReceivedOutput(pszText); // normal screen echo
	}
};
