// maindlg.cpp : implementation of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "maindlg.h"

LRESULT CMainDlg::OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	// center the dialog on the screen
	CenterWindow();

	// set icons
	HICON hIcon = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
		IMAGE_ICON, ::GetSystemMetrics(SM_CXICON), ::GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR);
	SetIcon(hIcon, TRUE);
	HICON hIconSmall = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
		IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
	SetIcon(hIconSmall, FALSE);

	// figure out the windows version
	OSVERSIONINFO osInfo;
	osInfo.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	::GetVersionEx(&osInfo);
	m_bIsWindowsNT = osInfo.dwPlatformId == VER_PLATFORM_WIN32_NT;

	m_pLastCommand = 0;
	m_bReusable = 0; // default==unchecked

	m_wEdit.SubclassWindow(GetDlgItem(IDC_OUTPUT));
	m_wEdit.LimitText(32766); // enough for 1000 lines or so

	return TRUE;
}

LRESULT CMainDlg::OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	CSimpleDialog<IDD_ABOUTBOX/*, FALSE*/> dlg;
	dlg.DoModal();
	return 0;
}

// this is actually the IDOK handler, for EZ trapping of the <Return> button
LRESULT CMainDlg::OnRun(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	// Q'n'D: instead of handling WM_GETDLGCODE trap the return key here... you wish!
	// even when RET is pressed in the edit window, GetFocus()==RunButton (!)

	// reset the "input buffer" info
	m_nStartChar = -1;

	TCHAR buf[128];
	*buf = 0;
	GetDlgItemText(IDC_COMMAND, buf, sizeof(buf)/sizeof(buf[0]));
	if(!buf[0]) {
		MessageBox(_T("Please enter a command to run"), _T("Demo"));
		CWindow(GetDlgItem(IDC_COMMAND)).SetFocus();
		return 0;
	}

	ATLASSERT(m_pLastCommand==0 || m_bReusable);
	// the new reusable mode has made a shambles out of my GUI structure...
	if(m_pLastCommand) {
		ATLASSERT(m_pLastCommand->m_dwFlags & CPF_REUSECMDPROC);
		// queue command to the existing command processor, like as if someone was typing it
		// SendChildInput could also have been used
		m_pLastCommand->Execute(buf);
		return 0;
	}

	CEdit out(GetDlgItem(IDC_OUTPUT));
	// create redirection plumbings
	DWORD flags = m_bReusable ? CPF_REUSECMDPROC : 0;
	m_pLastCommand = new CMyConsolePipe(m_bIsWindowsNT, out, flags);
	if(!m_pLastCommand)
		return 0; // rare: memory is tight

	int status = m_pLastCommand->Execute(buf);
	if(CPEXEC_OK == status) {
		CWindow button;
		// turn the break/kill button on & run button off
		button = GetDlgItem(IDC_BREAK);
		ATLASSERT(button.IsWindow());
		button.EnableWindow();
		::EnableWindow(GetDlgItem(IDC_KILL), TRUE);

		if(!m_bReusable) {
			button = GetDlgItem(IDOK/*run*/);
			ATLASSERT(button.IsWindow());
			button.EnableWindow(FALSE);
		}

		// in this particular sample we limit at one active command at a time
		// but the CConsolePipe class has no such limitations
		// (however you need a new instance for each new command -- unless in reusable mode)
	}
	else {
		// error conditions are rare since the intermediate command processor is always started
		// however if status==CPEXEC_MISC_ERROR you can try a no-frills CreateProcess

		// if the thread didn't start we have to cleanup manually
		ATLASSERT(!m_pLastCommand->IsChildRunning());
		delete m_pLastCommand;
		m_pLastCommand = 0;

		MessageBox(_T("Can't execute that!"), _T("Demo"));
		CEdit cmd(GetDlgItem(IDC_COMMAND));
		cmd.SetSel(0, -1);
		cmd.SetFocus();
	}

	return 0;
}

LRESULT CMainDlg::OnCancel(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	// for reusable mode, send the exit command
	if(m_pLastCommand && (m_pLastCommand->m_dwFlags & CPF_REUSECMDPROC) ) {
		ATLASSERT(m_bReusable);
		m_pLastCommand->StopCmd();

		// to avoid leaks, wait for the termination event (message)
		// but obviously since it's _sent_ i'll never know about it with a local message pump

		// wait for the bg thread to quit before ending the dialog
		ATLASSERT(!m_bDelayedQuit);
		m_bDelayedQuit = TRUE;
		return 0;
	}
	// any command left running... won't be living for long!

	if(m_bDelayedQuit)
		Sleep(100); // allow bg thread to cleanup

	EndDialog(wID); // sole exit point, also for <ESC>
	return 0;
}

// custom message sent from our derived pipe class, notifying of child finito
LRESULT CMainDlg::OnEndChildProcess(UINT /*uMsg*/, WPARAM wp, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	ATLASSERT(wp == (WPARAM)m_pLastCommand); // hint, but we don't actually use it

	CWindow button;
	// turn the break/kill buttons off & run button on
	button = GetDlgItem(IDC_BREAK);
	ATLASSERT(button.IsWindow());
	button.EnableWindow(FALSE);
	::EnableWindow(GetDlgItem(IDC_KILL), FALSE);

	button = GetDlgItem(IDOK);
	ATLASSERT(button.IsWindow());
	button.EnableWindow();

	m_pLastCommand = NULL; // shouldn't be accessed any further
	// the listener thread frees the object, since CPF_NOAUTODELETE wasn't specified
	
	if(m_bDelayedQuit) {
		ATLASSERT(m_bReusable);
		PostMessage(WM_COMMAND, IDCANCEL);
	}

	return 0;
}


// try this by typing a command that doesn't end naturally, like "more <CON:"
LRESULT CMainDlg::OnBreak(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	ATLASSERT(m_pLastCommand);

	m_pLastCommand->SendCtrlBrk();
	return 0;
}

// when all else fails, it's time for drastic actions
LRESULT CMainDlg::OnKill(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	ATLASSERT(m_pLastCommand);

	CMyConsolePipe* save = m_pLastCommand;
	// unfortunately this won't terminate the listener thread cleanly
	SendMessage(UWM_PIPEBROKEN, (WPARAM)save); // simulate event

	ATLASSERT(0==m_pLastCommand);
	save->Break();

	return 0;
}

// toggle the reuse flag/checkmark
LRESULT CMainDlg::OnReuseCmd(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	ATLASSERT(!m_bReusable);
	ATLASSERT(IsDlgButtonChecked(IDC_REUSE));

	m_bReusable = TRUE;
	// once in this mode, we can't get out of it for simplicity of interface/logic
	CWindow(GetDlgItem(IDC_REUSE)).EnableWindow(FALSE); 
	return 0;
}


/////////////////////////////////////////////////////////////////////////////
// handlers for the contained edit control

LRESULT CMainDlg::OnGetDlgCode(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
	return DLGC_WANTALLKEYS; // i just need <return>
}

// carefully obtain user input meant for the command processor
LRESULT CMainDlg::OnKey(UINT /*uMsg*/, WPARAM wParam, LPARAM /*lParam*/, BOOL& bHandled)
{
	bHandled = FALSE; // allow the character to be processed/displayed 
	if(!m_pLastCommand)
		return 0;

	// if this is the beginning of a "new" input, save the cursor position
	if(-1 == m_nStartChar) {
		int nEndChar;
		m_wEdit.GetSel(m_nStartChar, nEndChar);
	}

	// no need to handle WM_KEYDOWN, i can catch <return> here
	if(VK_RETURN == wParam) {
		// kludge: [m_nStartChar, thisChar] is considered the intended input
		// @@@ of course this "logic" can fail in many ways, eg arrow-moved to new line etc
		int nCur, nEndChar;
		m_wEdit.GetSel(nCur, nEndChar);
		ATLASSERT(m_nStartChar >= 0);
		if(nCur >= m_nStartChar) {
			// i had forgotten what a pain plain edit controls are!
			// EM_GETSELTEXT works only for richedits
			if(nCur != nEndChar)
				m_wEdit.SetSel(nCur, nCur); // cancel selection so that EM_LINELENGTH works ok

			int nStartLine = m_wEdit.LineIndex();
			ATLASSERT(nStartLine <= nCur);
			int nLen = m_wEdit.LineLength(nCur); // could be empty
			ATLASSERT(m_nStartChar <= nStartLine+nLen);

			ATLASSERT(sizeof(TCHAR)*nLen < 4096);
			LPTSTR pbuf = (LPTSTR)_alloca(sizeof(TCHAR) * (nLen + 3/*room for CR*/) );
			m_wEdit.GetLine(m_wEdit.LineFromChar(nCur), pbuf, nLen);
#ifdef DEBUG
			pbuf[nLen] = 0; // we don't get a terminator for free
			ATLASSERT(lstrlen(pbuf)==nLen);
#endif

			// i could have called Execute for convenient newline addition
			// but that isn't what we're actually doing, just passing info to the running proggy
			pbuf[nLen] = _T('\r');
			pbuf[nLen+1] = _T('\n');
			pbuf[nLen+2] = 0;
			if(m_nStartChar < nStartLine)
				m_nStartChar = nStartLine; // consecutive <Ret>s or other anomaly
			m_pLastCommand->SendChildInput(pbuf + m_nStartChar - nStartLine);
		}
		// else this is suspect, ignore!

		m_nStartChar = -1; // reset for next input cycle
	}
	else if(VK_CANCEL == wParam) {
		// whereas Pause on its own sends VK_PAUSE, with Ctrl it sends Cancel
		// basically no need to check for Control here
		m_pLastCommand->SendCtrlBrk();
	}

	return 0;
}
