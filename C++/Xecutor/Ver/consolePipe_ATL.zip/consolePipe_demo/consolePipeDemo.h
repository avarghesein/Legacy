// consolePipeDemo.h
