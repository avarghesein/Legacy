// consolePipeDemo.cpp : main source file for consolePipeDemo.exe
//

#include "stdafx.h"
#include "resource.h"
#include "maindlg.h"

CAppModule _Module;


int WINAPI _tWinMain(HINSTANCE hInstance, HINSTANCE /*hPrevInstance*/, LPTSTR lpstrCmdLine, int nCmdShow)
{
	// this resolves ATL window thunking problem when Microsoft Layer for Unicode (MSLU) is used
	::DefWindowProc(NULL, 0, 0, 0L);

	HRESULT hRes = _Module.Init(NULL, hInstance);
	ATLASSERT(SUCCEEDED(hRes));

	CMainDlg dlgMain;
	int nRet = dlgMain.DoModal();

	CConsolePipe::Term(); // cleanup any forced consoles

	_Module.Term();

	// add the leak tsekin thingme
	TSEKIT_LEAKZ();

	return nRet;
}
