#ifndef UPRIGHT_CRT_LEAKZ
#define UPRIGHT_CRT_LEAKZ

#ifndef _INC_CRTDBG
// too late for setting the 
#error ERROR: <crtdbg.h> not included, this file is useless without it
#endif


#ifdef _DEBUG // only for debug buildz

/* AUTOMATIC DUMPS OF LEAKED OBJECTS
 * This include file contains useful definitions and things for generating automatiche
 * dumps of leaked resources allocated via the CRT route (new/malloc etc). If you need
 * blocks other than _NORMAL_BLOCK, you need to define new overrides, as eg:
#ifdef _DEBUG
   #define DEBUG_CLIENTBLOCK   new( _CLIENT_BLOCK, __FILE__, __LINE__)
#else
   #define DEBUG_CLIENTBLOCK
#endif
 * "Client" blocks are a bit more advanced enabling custom hooks to be used by CRT when
 * dumping, but the main objective is to detect the leaks, not playing fancy games.
 *
 * In the end I had to forget about automatic _CRTDBG_MAP_ALLOC and roll out my own
 * definitions here, coz the standard implementation of new() was "inline" which meant
 * that the leak was always reported from the header file instead of the actual place
 * in my own code!
 */

#define   malloc(s)         _malloc_dbg(s, _NORMAL_BLOCK, __FILE__, __LINE__)
#define   calloc(c, s)      _calloc_dbg(c, s, _NORMAL_BLOCK, __FILE__, __LINE__)
#define   realloc(p, s)     _realloc_dbg(p, s, _NORMAL_BLOCK, __FILE__, __LINE__)
#define   _expand(p, s)     _expand_dbg(p, s, _NORMAL_BLOCK, __FILE__, __LINE__)
#define   free(p)           _free_dbg(p, _NORMAL_BLOCK)
#define   _msize(p)         _msize_dbg(p, _NORMAL_BLOCK)

// fingers crossed this should work...
#define  new new(_NORMAL_BLOCK, __FILE__, __LINE__)

// add this in the end of the program for auto testing of leaks and heap consistency
// by default, nowt is checked, since the crt memory settings are:
// _CRTDBG_ALLOC_MEM_DF == _CrtSetDbgFlag( _CRTDBG_REPORT_FLAG );
// If _CRTDBG_LEAK_CHECK_DF is on, then automatically leaks are tested @ exit
// _CrtCheckMemory is not for leaks but for buffer under/overruns etc
#define 	TSEKIT_LEAKZ() \
	_ASSERTE( _CrtCheckMemory( ) ); \
	_CrtSetDbgFlag(_CrtSetDbgFlag( _CRTDBG_REPORT_FLAG ) | _CRTDBG_LEAK_CHECK_DF); \
	// _CrtDumpMemoryLeaks(); will be auto called by CRT

#else // release versions
#define 	TSEKIT_LEAKZ()

#endif // #ifdef _DEBUG


#endif // #ifndef UPRIGHT_CRT_LEAKZ