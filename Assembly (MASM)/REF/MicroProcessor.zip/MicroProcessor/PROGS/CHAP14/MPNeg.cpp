// MPNeg.cpp

//  Program text from "Assembly Language for the IBM PC Family" by
//   William B. Jones, (c) Copyright 2001, Scott/Jones Inc.

#include <iostream.h>

void MPNeg(int A[], int Len)
{
   _asm {
        mov     esi, A
        sub     ebx, ebx ;  ebx = 0
        mov     ecx, Len
        stc     ;   add 1 to 1's complement
NegLoop:
        not     DWORD PTR [esi + 4 * ebx]
        adc     DWORD PTR [esi + 4 * ebx], 0
        inc     ebx
        dec     cx
        jnz     NegLoop
   }
}

int main()
{
    int A[] = {0, 1};
    MPNeg(A, 2);
    cout << hex << A[1] << ", " << A[0] << endl;
    return 0;
}
