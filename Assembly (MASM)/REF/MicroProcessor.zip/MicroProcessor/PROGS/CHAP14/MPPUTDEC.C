// MPPutDec.c-multiple precision display unsigned

//  Library source text from "Assembly Language for the IBM PC Family" by
//   William B. Jones, (c) Copyright 2001 Scott/Jones Inc.

#include <stdio.h>

void MPPutDec(int A[], int Len)
{
    int DigCt = 0, NZD;
   _asm {
        mov edi, esp
        sub edi, 4 ;    edi = address of A[Len - 1]
        
        mov ecx, Len
        mov esi, ecx
        dec esi
        shl esi, 2 ; esi = 4 * (Len - 1)
        add esi, A ;  si --> last double word of A
    MovIn:
        push    DWORD PTR [esi]
        sub esi, 4
        dec cx
        jnz MovIn

        mov ebx, 10 ;    The divisor
    }
    do {
        NZD = 0;
        ++ DigCt;
//   compute ACopy = ACopy / 10; remainder --> edx
        _asm {
            mov esi, edi ;   Left end in fixed position rel bp
            mov ecx, Len
            mov edx, 0 ;     Initial high-order bits of dividend
    DivideBy10:
            mov eax, [esi] ;   edx|eax = prev remdr|brought down
;                       next digit
            div ebx
            mov [esi], eax
            test    eax, eax
            jz  ZeroResult
            mov NZD, 1 ;    Quotient is non-zero; another step needed
    ZeroResult:
            sub esi, 4
            dec cx
            jnz     DivideBy10 ;  End of divide by 10

            add dl, '0' ;   Convert final remainder to ASCII digit
            push    edx
        }
    } while (NZD != 0);

    while (--DigCt >= 0) {
        char c;
        _asm {
            pop eax
            mov c, al
        }
        putchar(c);
    }
}

