// MPPutDec.c-multiple precision display unsigned

//  Library source text from "Assembly Language for the IBM PC Family" by
//   William B. Jones, (c) Copyright 2001 Scott/Jones Inc.

extern void MPPutDec(int[], int);

int main()
{
    int A[2];
    _asm {
        mov     eax, 123456
        mov     ebx, 1000000
        imul    ebx
        mov     A, eax
        mov     A+4, edx
    }
    MPPutDec(A, 2);
    return 0;
}
