// random.c-minimal standard random number generator

//  Program text from "Assembly Language for the IBM PC Family" by
//   William B. Jones, (c) Copyright 1992, 1997, 2001, Scott/Jones Inc.

extern int Seed;

int random()
{
   const int A = 16807;
   _asm {
        mov     eax, A
        mul     Seed
        shld    edx, eax, 1
        and     eax, 7FFFFFFFh
        add     eax, edx
        test    eax, 80000000h
        jz      noMore
        add     eax, 80000001h
noMore:
        mov     Seed, eax
   }
   return Seed;
}

