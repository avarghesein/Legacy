// mpaddtst.c--program to test mpadd.c

//   Program text from "Assembly Language for the IBM PC Family" by
//   William B. Jones, (c) Copyright 2001, Scott/Jones Inc.
 
extern void MPAdd(int[], int[], int);
extern void MPPutDec(int[], int);

#include <stdio.h>

int main()
{
    int A[] = {4000000000, 0}, B[] = {4000000000, 0};
    MPAdd(A, B, 2);
    MPPutDec(A, 2);
    putchar('\n');
    return 0;
}
    
