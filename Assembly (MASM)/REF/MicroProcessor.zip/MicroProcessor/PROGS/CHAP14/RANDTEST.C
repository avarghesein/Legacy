// randtest.c

//  Program text (c) Copyright 1992, 1997, 2001, Scott/Jones Inc.

#include <stdio.h>

extern int random();
int Seed = 1;   // for test purposes

int main()
{
    int i, r;
    for (i = 0; i < 10000; ++i) r = random();
    printf("%d should equal 1043618065\n", r);
    return 0;
}
