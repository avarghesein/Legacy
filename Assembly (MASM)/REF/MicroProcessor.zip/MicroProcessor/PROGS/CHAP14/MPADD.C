// MPAdd.c-multiple precision add

//   Program text from "Assembly Language for the IBM PC Family" by
//   William B. Jones, (c) Copyright 2001, Scott/Jones Inc.
 
void MPAdd(int A[], int B[], int Len)
{
   _asm {
        mov     edi, A
        mov     esi, B
        sub     ebx, ebx ; ebx = 0
        mov     ecx, Len
        clc
AddLoop:
        mov     eax, [esi + 4 * ebx] ;  eax = B[i]
        adc     [edi + 4 * ebx], eax ;  A[i] = A[i] + B[i]
        inc     ebx ;           avoid destroying C Flag!
        dec     cx
        jnz     AddLoop
   }
}

