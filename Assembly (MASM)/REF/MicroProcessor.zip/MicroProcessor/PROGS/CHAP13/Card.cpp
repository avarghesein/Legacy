// Card.cpp--C function with assembly to compute the
//  number of 1 bits in a 32 bit integer

//  Program text from "Assembly Language for the IBM PC Family" by
//   William B. Jones, (c) Copyright 2001, Scott/Jones Inc.

#include <iostream.h>

int Card(int s)
{
     int value;
     _asm {
            mov eax, s
            sub ecx, ecx
    countLoop:
            test    eax, eax
            jz      Done
            shr eax, 1
            jnc countLoop
            inc ecx
            jmp countLoop
    Done:
            mov value, ecx
     }
     return value;
}

int main()
{
    cout << "enter a number ";
    int x;
    cin >> x;
    cout << "The number of bits in 0x" << hex << x << " is " << dec << Card(x) << endl;
    return 0;
}
